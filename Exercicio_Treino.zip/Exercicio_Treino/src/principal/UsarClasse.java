
package principal;

import java.util.Scanner;
import model.Paciente;

public class UsarClasse {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Paciente paciente1 =  new Paciente();
        
        System.out.println("Digite o nome do paciente: ");
        paciente1.setNome(entrada.nextLine());
         
        System.out.println("Digite o rg do paciente: ");
        paciente1.setRg(entrada.nextLine());
        
        System.out.println("Digite o endereço do paciente: ");
        paciente1.setEndereco(entrada.nextLine());
        
        System.out.println("Digite o Telefone do paciente: ");
        paciente1.setTelefone(entrada.nextLine());
         
        System.out.println("Digite a Data de Nascimento do paciente: ");
        paciente1.setDataNascimento(entrada.nextLine());
         
        System.out.println("Digite a profissão do paciente: ");
        paciente1.setProfissao(entrada.nextLine());
         
        //System.out.println(paciente1.imprimir());//
        System.out.println(paciente1.toString());
    }
    
    
}