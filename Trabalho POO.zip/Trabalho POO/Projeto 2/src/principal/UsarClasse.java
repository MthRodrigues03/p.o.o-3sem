package principal;
import java.util.Scanner;
import model.Triangulo;

public class UsarClasse {
    public static void main(String[] args) {
        
        Triangulo trian1 = new Triangulo();
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite a base do retângulo: ");
        double base = scanner.nextDouble();
        System.out.print("Digite a altura do retângulo: ");
        double altura = scanner.nextDouble();
        trian1.setBase(base);
        trian1.setAltura(altura);
        
        
        Triangulo trian2 = new Triangulo(5.0, 3.0);
        
        // Imprimindo informações dos retângulos
        System.out.println("Retângulo 1:");
        System.out.println("Base: " + trian1.getBase());
        System.out.println("Altura: " + trian1.getAltura());
        System.out.println("Área: " + trian1.calcularArea());
        
        System.out.println("Retângulo 2:");
        System.out.println("Base: " + trian2.getBase());
        System.out.println("Altura: " + trian2.getAltura());
        System.out.println("Área: " + trian2.calcularArea());
        
    
        
        
        
    }
        
    
}
