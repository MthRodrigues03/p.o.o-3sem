
package projeto4;

import java.util.Scanner;

/**
 *
 * @author Matheus
 */
public class Projeto4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Informe as vendas: ");
        float vendas = sc.nextFloat();
        
        System.out.print("Informe o salário: ");
        float salario = sc.nextFloat();
        
        sc.nextLine();
        System.out.print("Informe seu nome: ");
        String nome = sc.nextLine();
        
        System.out.print("Informe a quantidade de faltas: ");
        int faltas = sc.nextInt();
        
        Vendedor vendUm = new Vendedor(vendas, salario, nome, faltas);
        
        vendUm.imprimirDados();
        
       
        
    }
    
}
