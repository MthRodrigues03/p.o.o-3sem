
package projeto4;

/**
 *
 * @author Matheus
 */
public class Vendedor {
    private float vendas;
    private float salario;
    private String nome;
    private int falta;

    public Vendedor() {
    }

    public Vendedor(float vendas, float salario, String nome, int falta) {
        this.vendas = vendas;
        this.salario = salario;
        this.nome = nome;
        this.falta = falta;
    }

    public float getVendas() {
        return vendas;
    }

    public void setVendas(float vendas) {
        this.vendas = vendas;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFalta() {
        return falta;
    }

    public void setFalta(int falta) {
        this.falta = falta;
    }
    
    public void imprimirDados() {
        System.out.println("Vendas: " + this.vendas);
        System.out.println("Salário: " + this.salario);
        System.out.println("Nome: " + this.nome);
        System.out.println("Falta: " + this.falta);
        System.out.println("Comissão: " + calcularComissao());
        System.out.println("Desconto das faltas: " + descontoFalta());
        System.out.print("Salário final: ");    
        calcularSalario();
    }
    
    public double calcularComissao() {
        double comissao = 0;
        if(this.vendas >= 1000 && this.vendas < 2000){
            comissao = this.vendas * 0.1;
        }
        else if( this.vendas >= 2000) {
            comissao = this.vendas * 0.15;
        }
        return comissao;
    }
    
    public float descontoFalta() {
        return this.salario / 30 * falta;
    }
    
    public void calcularSalario() {
        System.out.println((float) (this.salario + calcularComissao() - descontoFalta()));
    }
}
