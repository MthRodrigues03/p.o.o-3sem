
package principal;


import model.Funcionario;

public class UsarClasse {
    public static void main(String[] args) {
        Funcionario func1 = new Funcionario();
        func1.setCrasha(12345);
        func1.setSalario(3000);
        
        Funcionario func2 = new Funcionario(321, 4000, "Desenvolvedor");
        
        func1.calcularAumento(10.5 );
        func1.calcularAumento(10 );
        func2.calcularAumento(4.5);
        func2.calcularAumento(10);
        
        
        System.out.println("Funcionario 1 recebe antes do aumento: ");
        System.out.println("Cracha: " +func1.getCrasha());
        System.out.println("Salario: " +func1.getSalario());
        System.out.println("Cargo: " +func1.getCargo());
        
        System.out.println("Funcionario 2 recebe antes do aumento: ");
        System.out.println("Cracha: " +func2.getCrasha());
        System.out.println("Salario: " +func2.getSalario());
        System.out.println("Cargo: " +func2.getCargo());
    }
}
