
package model;

public class Funcionario {
    
    public int crasha;
    public float salario;
    public String cargo;

    public Funcionario(int crasha, float salario, String cargo) {
        this.crasha = crasha;
        this.salario = salario;
        this.cargo = cargo;
    }
    
    public Funcionario(){
        this.cargo = "assistente";
    }
    
    public double calcularAumento(double porcentagem){
        this.salario += this.salario * (porcentagem/100);
        return salario;
    }
    
    public int calcularAumento(int tempo){
        this.salario += 150 * tempo;
        return tempo;
        
    }

    public int getCrasha() {
        return crasha;
    }

    public void setCrasha(int crasha) {
        this.crasha = crasha;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    
}
