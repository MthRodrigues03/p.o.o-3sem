package model;

/**
 *
 * @author Matheus F
 */
public class Torneio {
    String nome;
    int idade;
    String categoria;

    public Torneio(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        this.categoria = verificarCategoria();
    }

    public Torneio() {
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String n) {
        this.nome = n;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int i) {
        if(i <= 4){
            System.out.println("Você não tem idade para disputar o torneio");
        }
        this.idade = i;
    }
    
    public String getCategoria() {
        return categoria;
    }

    
    public String verificarCategoria() {
        if (idade >= 5 && idade <= 7) {
            return "Infantil";
        } else if (idade >= 8 && idade <= 10) {
            return "Juvenil";
        } else if (idade >= 11 && idade <= 15) {
            return "Adolescente";
        } else if (idade >= 16 && idade <= 30) {
            return "Adulto";
        } else {
            return "Sênior";
        }
    }
    
    public void imprimirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Categoria: " + categoria);
    }

    
}

        
        
    

