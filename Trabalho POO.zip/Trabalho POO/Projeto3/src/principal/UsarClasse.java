
package principal;

import model.Torneio;

public class UsarClasse {
     public static void main(String[] args) {
        // Instanciar objetos
        Torneio atleta1 = new Torneio("Fulano", 25);
        Torneio atleta2 = new Torneio("Ciclano", 10);

        // Imprimir dados dos objetos
        atleta1.imprimirDados();
        atleta2.imprimirDados();
    }
}