/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @Matheus de França Rodrigues
 */
public class aluno {
    private String Nome;
    private String rgm;
    private int idade;
    private double nota1;
    private double nota2;

    public void setNome(String Nome) {

        if (Nome.length() >= 3) {
            this.Nome = Nome;

        } else {
            System.out.println("O nome do aluno deve ter 3 ou mais caracteres");

        }

    }

    public void setRgm(String rgm) {

        if (rgm.length() == 6) {
            this.rgm = rgm;
            
        } else {
            System.out.println("O RGM do aluno deve ter 6 caracteres");
        }

    }

    public void setIdade(int idade) {

        if (idade > 6) {
            this.idade = idade;
        } else {
            System.out.println("O aluno dever ter 17 anos ou mais");
        }

    }

    public void setNota1(double nota1) {

        if (nota1 > 0 && nota1 <= 10) {
            this.nota1 = nota1;

        } else {
            System.out.println("A nota 2 deve ser entre 0 e 10");
        }

    }

    public void setNota2(double nota2) {

        if (nota2 > 0 && nota2 <= 10) {
            this.nota2 = nota2;

        } else {
            System.out.println("A nota 2 deve ser entre 0 e 10");
        }

    }

    public String getNome(String nextLine) {
        return Nome;
    }

    public String getRgm(String nextLine) {
        return rgm;
    }

    public int getIdade(String next) {
        return idade;
    }

    public double getNota1(double nextDouble) {
        return nota1;
    }

    public double getNota2(double nextDouble) {
        return nota2;
    }

    @Override
    public String toString() {
        return "Nome do aluno: " + this.Nome +
                "\nRGM do aluno: " + this.rgm +
                "\nIdede do aluno: " + this.idade +
                "\nNota 1 do aluno: " + this.nota1 +
                "\nNota 2 do aluno: " + this.nota2 +
                "\nA media foi: " + calcularMédia(this.nota1, this.nota2) +
                "\nO status foi: " + VerificarAprovacao(calcularMédia(this.nota1, this.nota2));
    }

    public double calcularMédia(double nota1, double nota2) {
        return (nota1 + nota2) / 2;
    }

    public String VerificarAprovacao(double nota) {
        String status;

        if (nota >= 6) {
            status = "Aprovado";
        } else {
            status = "Reprovado";
        }

        return status;
    }

}
