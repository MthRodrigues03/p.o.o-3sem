/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import java.util.Scanner;
import model.aluno;

/**
 *
 * @author alison
 */
public class usaClasses {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        aluno aluno1 =  new aluno();
        
        System.out.println("Digite o nome de aluno: ");
        aluno1.setNome(entrada.nextLine());
        
        System.out.println("Digite o RGM do aluno: ");
        aluno1.setRgm(entrada.nextLine());
        
        
        System.out.println("Digite a idede do aluno: ");
        aluno1.setIdade(entrada.nextInt());
        
        System.out.println("Digite a nota1 do aluno: ");
        aluno1.setNota1(entrada.nextDouble());
        
        System.out.println("Digite a nota2 do aluno: ");
        aluno1.setNota2(entrada.nextDouble());
        
        System.out.println(aluno1.toString());
        
    }
  
}
